class Price {
    private int  price;


    Price(int price){
        this.price = price;
    }
    public int getPrice() {
        return price;
    }

    boolean isNegative(){
        if(this.price<0)
            return true;
        else
            return false;
    }
    Price add(Price p){
        Price y = new Price(p.price + this.price);
        return y;
    }
    Price subtract(Price p){
        Price y = new Price(this.price - p.price );
        return y;
    }
    Price multiply(int n){
        Price y = new Price(this.price * n);
        return y;
    }
    boolean greaterOrEqual(Price p){
        if(this.price>=p.price)
            return true;
        else
            return false;

    }
    boolean lessOrEqual (Price p){
        if(this.price<=p.price)
            return true;
        else
            return false;
    }
    boolean greaterThan (Price p){
        if(this.price>p.price)
            return true;
        else
            return false;
    }
    boolean lessThan (Price p){
        if(this.price<p.price)
            return true;
        else
            return false;
    }
    @Override
    public boolean equals(Object o) {
        boolean result;
        Price y = (Price) o;

        if (this.price < y.price) {
            result = true;
        } else {
            result = false;
        }
        return result;
    }
    int compareTo(Price p){
        return (this.price - p.price)%100;
    }
    public String toString(){
        float i = this.price/ 100;
        String s=String.valueOf(i);
        s= '$'+s;
        return s;
    }

    public int hashCode(){
        int j = this.price;
        return j^(j<<9);
    }
}
