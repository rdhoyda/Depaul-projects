// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
//        Scanner obj = new Scanner(System.in);
//        System.out.println("Enter price in cents");
//        int i = obj.nextInt();
//        System.out.println("Enter price in  String format");
//        Scanner ob = new Scanner(System.in);
//        String j = ob.nextLine();


        Price x=  PriceFactory.makePrice(1230);
        Price y=  PriceFactory.makePrice("12.10");
        System.out.println("price of 1st obj : " + x.getPrice());
        System.out.println("price of 2nd obj : " + y.getPrice());
        System.out.println("price of 1st obj is negative : " + x.isNegative());

        System.out.println("adding price of 1st and 2nd obj : " + x.add(y).getPrice());
        System.out.println("subtracting price of 1st and 2nd obj : " + x.subtract(y).getPrice());
        System.out.println("multiplying price of 1st obj with 10: " + x.multiply(10).getPrice());
        System.out.println("checking if price of 1st obj is greater or equal to  2nd obj " + x.greaterOrEqual(y));
        System.out.println("checking if price of 1st obj is less or equal to 2nd obj " + x.lessOrEqual(y));
        System.out.println("checking if price of 1st obj is greater than 2nd obj " + x.greaterThan(y));
        System.out.println("checking if price of 1st obj is less than 2nd obj " + x.lessThan(y));
        System.out.println("checking if price of 1st obj is equal to 2nd obj " + x.equals(y));
        System.out.println("difference between cents in 1st and 2nd obj " + x.compareTo(y));
        System.out.println("Print obj1 price in string format " + x.toString());
        System.out.println("Print obj1 price in hashcode " + x.hashCode());






    }
}