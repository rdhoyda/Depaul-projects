import java.text.DecimalFormat;

class PriceFactory{
    public static Price makePrice(int value){

        Price p = new Price(value);
        return  p;
    }
    public static Price makePrice(String stringValueIn){
        String s = stringValueIn.replace("$","");
        s=s.replace(",","");
        float f =Float.parseFloat(s);
        DecimalFormat df = new DecimalFormat("0.00");
        f = Float.parseFloat(df.format(f));

        int i = (int) (f * 100);
        Price p = new Price(i);
        return   p;
    }
}
