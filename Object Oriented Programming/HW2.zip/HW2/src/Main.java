
public class Main {
    public static void main(String[] args) {
        // Create a ProductBook
        ProductBook productBook = new ProductBook("TGT");

        // Create some Price objects using the PriceFactory
        Price price1 = PriceFactory.createPrice(10.00);
        Price price2 = PriceFactory.createPrice(9.95);
        Price price3 = PriceFactory.createPrice(9.90);
        Price price4 = PriceFactory.createPrice(10.10);
        Price price5 = PriceFactory.createPrice(10.20);
        Price price6 = PriceFactory.createPrice(10.25);
        // Create some Order objects
        Order order1 = new Order("AAA", "TGT", price1, BookSide.BUY, 50);
        Order order2 = new Order("BBB", "TGT", price1, BookSide.BUY, 60);
        Order order3 = new Order("CCC", "TGT", price2, BookSide.BUY, 70);
        Order order4 = new Order("DDD", "TGT", price3, BookSide.BUY, 25);
        Order order5 = new Order("EEE", "TGT", price4, BookSide.SELL, 120);
        Order order6 = new Order("EEE", "TGT", price5, BookSide.SELL, 45);
        Order order7 = new Order("FFF", "TGT", price6, BookSide.SELL, 90);
        Order order8 = new Order("AAA", "TGT", price1, BookSide.SELL, 200);
        Order order9 = new Order("BBB", "TGT", price4, BookSide.BUY, 200);
        Order order10 = new Order("EEE", "TGT", price1, BookSide.SELL, 90);
        Order order11 = new Order("CCC", "TGT", price3, BookSide.SELL, 95);
        Order order12 = new Order("DDD", "TGT", price6, BookSide.BUY, 100);
        // Add the orders to the ProductBook and print the state after each addition
        System.out.println("1) --------------------------------------------------------------");
        System.out.println("ADD: BUY: " + order1);
        productBook.add(order1);
        System.out.println(productBook);

        System.out.println("2) --------------------------------------------------------------");
        System.out.println("ADD: BUY: " + order2);
        productBook.add(order2);
        System.out.println(productBook);

        System.out.println("3) --------------------------------------------------------------");
        System.out.println("ADD: BUY: " + order3);
        productBook.add(order3);
        System.out.println(productBook);

        System.out.println("4) --------------------------------------------------------------");
        System.out.println("ADD: BUY: " + order4);
        productBook.add(order4);
        System.out.println(productBook);

        System.out.println("5) --------------------------------------------------------------");
        System.out.println("ADD: SELL: " + order5);
        productBook.add(order5);
        System.out.println(productBook);

        System.out.println("6) --------------------------------------------------------------");
        System.out.println("ADD: SELL: " + order6);
        productBook.add(order6);
        System.out.println(productBook);

        System.out.println("7) --------------------------------------------------------------");
        System.out.println("ADD: SELL: " + order7);
        productBook.add(order7);
        System.out.println(productBook);

        System.out.println("8) --------------------------------------------------------------");
        System.out.println("ADD: SELL: " + order8);
        productBook.add(order8);
        System.out.println(productBook);

        System.out.println("9) --------------------------------------------------------------");
        System.out.println("ADD: BUY: " + order9);
        productBook.add(order9);
        System.out.println(productBook);

        System.out.println("10) --------------------------------------------------------------");
        System.out.println("CANCEL: " + order10);
        productBook.cancel(BookSide.SELL, order10.getId());
        System.out.println(productBook);


        System.out.println("11) --------------------------------------------------------------");
        System.out.println("ADD: SELL: " + order11);
        productBook.add(order11);
        System.out.println(productBook);

        System.out.println("12) --------------------------------------------------------------");
        System.out.println("ADD: BUY: " + order12);
        productBook.add(order12);
        System.out.println(productBook);


    }}