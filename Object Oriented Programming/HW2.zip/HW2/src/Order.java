

public class  Order{
    private final String user;
    private final String product;
    private final Price price;
    private final BookSide side;
    private final String id;
    private final int originalVolume;
    private int remainingVolume;
    private int cancelledVolume;
    private int filledVolume;

    public Order(String user, String product, Price price, BookSide side, int originalVolume) {
        this.user = user;
        this.product = product;
        this.price = price;
        this.side = side;
        this.id = generateId();
        this.originalVolume = originalVolume;
        this.remainingVolume = originalVolume;
        this.cancelledVolume = 0;
        this.filledVolume = 0;
    }

    public String getUser() {
        return user;
    }

    public String getProduct() {
        return product;
    }

    public Price getPrice() {
        return price;
    }

    public BookSide getSide() {
        return side;
    }

    public String getId() {
        return id;
    }

    public int getOriginalVolume() {
        return originalVolume;
    }

    public int getRemainingVolume() {
        return remainingVolume;
    }

    public void setRemainingVolume(int remainingVolume) {
        this.remainingVolume = remainingVolume;
    }

    public int getCancelledVolume() {
        return cancelledVolume;
    }

    public void addCancelledVolume(int volume) {
        this.cancelledVolume += volume;
    }

    public int getFilledVolume() {
        return filledVolume;
    }

    public void fill(int volume) {
        filledVolume += volume;
        remainingVolume -= volume;
    }

    private String generateId() {
        long nanoTime = System.nanoTime();
        return user + product + price.toString() + nanoTime;
    }

    @Override
    public String toString() {
        return user + " order: " + side + " " + product + " at " + price + ", Orig Vol: " + originalVolume +
                ", Rem Vol: " + remainingVolume + ", Fill Vol: " + filledVolume + ", CXL Vol: " + cancelledVolume +
                ", ID: " + id;
    }

    public OrderDTO makeTradableDTO() {
        return new OrderDTO(this);
    }
}
