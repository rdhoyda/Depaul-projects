

import java.util.HashMap;
import java.util.Map;

public class PriceFactory {
    private static final HashMap<Double, Price> priceMap = new HashMap<>();

    public static Price createPrice(double priceValue) {
        if (priceMap.containsKey(priceValue)) {
            return priceMap.get(priceValue);
        } else {
            Price price = new Price(priceValue);
            priceMap.put(priceValue, price);
            return price;
        }
    }
}
