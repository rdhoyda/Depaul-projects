

public class Price {
    private double price;

    public Price(double price) {
        this.price = price;
    }

    public double getPrice() {
        return price;
    }

    @Override
    public String toString() {
        return String.format("$%.2f", price);
    }
}
