
import java.util.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

// ProductBookSide class representing one side (Buy or Sell) of a product book
class ProductBookSide {
    private final BookSide side;
    private final Map<Price, List<Order>> bookEntries;

    public ProductBookSide(BookSide side) {
        this.side = side;
        this.bookEntries = new HashMap<>();
    }

    public OrderDTO add(Order order) {
        Price price = order.getPrice();
        List<Order> orders = bookEntries.computeIfAbsent(price, k -> new ArrayList<>());
        orders.add(order);
        return order.makeTradableDTO();
    }

    public OrderDTO cancel(String orderId) {
        for (List<Order> orders : bookEntries.values()) {
            for (Order order : orders) {
                if (order.getId().equals(orderId)) {
                    orders.remove(order);
                    order.setRemainingVolume(0);
                    order.addCancelledVolume(order.getRemainingVolume());
                    return order.makeTradableDTO();
                }
            }
        }
        return null;
    }

    public Price topOfBookPrice() {
        if (bookEntries.isEmpty()) {
            return null;
        }

        if (side == BookSide.BUY) {
            return bookEntries.keySet().stream()
                    .max(Comparator.comparingDouble(Price::getPrice))
                    .orElse(null);
        } else {
            return bookEntries.keySet().stream()
                    .min(Comparator.comparingDouble(Price::getPrice))
                    .orElse(null);
        }
    }

    public int topOfBookVolume() {
        Price topPrice = topOfBookPrice();
        if (topPrice != null) {
            return bookEntries.get(topPrice).stream()
                    .mapToInt(Order::getRemainingVolume)
                    .sum();
        }
        return 0;
    }

    public void tradeOut(Price price, int volume) {
        if (bookEntries.containsKey(price)) {
            List<Order> orders = bookEntries.get(price);
            Iterator<Order> iterator = orders.iterator();
            int remainingVolume = volume;
            while (iterator.hasNext() && remainingVolume > 0) {
                Order order = iterator.next();
                int orderVolume = order.getRemainingVolume();
                int tradeVolume = Math.min(orderVolume, remainingVolume);
                order.fill(tradeVolume);
                remainingVolume -= tradeVolume;
                if (order.getRemainingVolume() == 0) {
                    iterator.remove();
                }
            }
            if (orders.isEmpty()) {
                bookEntries.remove(price);
            }
        }
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Side: ").append(side).append("\n");
        for (Map.Entry<Price, List<Order>> entry : bookEntries.entrySet()) {
            Price price = entry.getKey();
            sb.append("Price: ").append(price).append("\n");
            List<Order> orders = entry.getValue();
            for (Order order : orders) {
                sb.append(order).append("\n");
            }
        }
        return sb.toString();
    }
}
