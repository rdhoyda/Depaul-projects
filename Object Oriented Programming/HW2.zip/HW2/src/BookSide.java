public enum BookSide {
    SELL, BUY

}