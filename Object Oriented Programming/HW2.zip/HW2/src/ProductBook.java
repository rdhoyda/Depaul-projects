

public class ProductBook {
    private String product;
    private ProductBookSide buySide;
    private ProductBookSide sellSide;

    public ProductBook(String product) {
        this.product = product;
        this.buySide = new ProductBookSide(BookSide.BUY);
        this.sellSide = new ProductBookSide(BookSide.SELL);
    }

    public OrderDTO add(Order o) {
        ProductBookSide bookSide = o.getSide() == BookSide.BUY ? buySide : sellSide;
        OrderDTO orderDTO = bookSide.add(o);
        tryTrade();
        return orderDTO;
    }

    public OrderDTO cancel(BookSide side, String orderId) {
        ProductBookSide bookSide = side == BookSide.BUY ? buySide : sellSide;
        return bookSide.cancel(orderId);
    }
    public void tryTrade() {
        ProductBookSide buySide = this.buySide;
        ProductBookSide sellSide = this.sellSide;

        Price buyPrice = buySide.topOfBookPrice();
        Price sellPrice = sellSide.topOfBookPrice();

        if (buyPrice != null && sellPrice != null && buyPrice.getPrice() >= sellPrice.getPrice()) {
            int buyVolume = buySide.topOfBookVolume();
            int sellVolume = sellSide.topOfBookVolume();
            int tradeVolume = Math.min(buyVolume, sellVolume);

            buySide.tradeOut(buyPrice, tradeVolume);
            sellSide.tradeOut(sellPrice, tradeVolume);

            tryTrade(); // Check for further trades recursively
        }
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Product: ").append(product).append("\n");
        sb.append("Side: BUY\n").append(buySide.toString()).append("\n");
        sb.append("Side: SELL\n").append(sellSide.toString()).append("\n");
        return sb.toString();
    }
}