

public class OrderDTO {
    public final String user;
    public final String product;
    public final Price price;
    public final BookSide side;
    public final String id;
    public final int originalVolume;
    public final int remainingVolume;
    public final int cancelledVolume;
    public final int getfilledVolume;

    public OrderDTO(Order o) {
        this.user = o.getUser();
        this.product = o.getProduct();
        this.price = o.getPrice();
        this.side = o.getSide();
        this.id = o.getId();
        this.originalVolume = o.getOriginalVolume();
        this.remainingVolume = o.getRemainingVolume();
        this.cancelledVolume = o.getCancelledVolume();
        this.getfilledVolume = o.getFilledVolume();
    }

    @Override
    public String toString() {
        return user + " order: " + side + " " + product + " at " + price + ", Orig Vol: " + originalVolume +
                ", Rem Vol: " + remainingVolume + ", Fill Vol: " + getfilledVolume + ", CXL Vol: " + cancelledVolume +
                ", ID: " + id;
    }
}
