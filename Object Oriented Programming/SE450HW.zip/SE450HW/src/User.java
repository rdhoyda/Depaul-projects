

import java.util.*;

public class User {

    private final String userId;
    private  HashMap<String, OrderDTO> userOrders = new HashMap<>();

    public User(String userId) throws OrderValidationException {

        this.userId = setUserId(userId);
    }

    private String setUserId(String userId) throws OrderValidationException {

        if(userId == null || !userId.matches("^[A-Za-z]{3}$"))
        {throw new OrderValidationException("Verify user code passed in");}
        return userId;

    }

    public String getUserID() {
        return userId;
    }

    public void addOrder(OrderDTO o) throws OrderValidationException {
        if(o == null)
            throw new OrderValidationException(" Verify order DTO passed in,it cannot be null");
        else{
            userOrders.put(o.id, o); }
    }

    public boolean hasOrderWithRemainingQty()
    {
        boolean bool = false;
        for(OrderDTO dto : this.userOrders.values())
        {
            if(dto.remainingVolume > 0)
                bool = true;

        }
        return bool;
    }

    public OrderDTO getOrderWithRemainingQty()
    {
        OrderDTO odrDto = null;
        for(OrderDTO dto : this.userOrders.values())
        {
            if(dto.remainingVolume > 0)
                odrDto = dto;
            break;
        }
        return odrDto;
    }

    @Override
    public String toString() {

        StringBuilder str = new StringBuilder();
        str.append("User Id: "+getUserID()).append("\n");

        for(OrderDTO order : this.userOrders.values())
            str.append("Product: "+order.product+ " Price: "+order.price+" OriginalVolume: "+order.originalVolume+" RemainingVolume: "+order.remainingVolume+" CancelledVolume: "+
                    order.cancelledVolume+" FilledVolume: "+order.filledVolume+" User: "+order.user+" side: "+
                    order.user+" Id: "+order.id).append('\n');


        return str.toString();
    }
}
