

import java.util.HashMap;
import java.util.Map;

public abstract class PriceFactory {
    static HashMap<Integer, Price> factoryMap = new HashMap<>();
    public static Price makePrice(int priceint) {
        Price price = null;
        if(!factoryMap.containsKey(priceint)) {
            price = new Price(priceint);
            factoryMap.put(priceint,price);
            return price;
        }
        else
            return factoryMap.get(priceint);
    }

    public static Price makePrice(String pricedol){
        String price = pricedol;

        if (price.contains("$"))
            price = pricedol.replace("$", "");
        if (price.contains("-"))
            price = price.replace("-", "");
        if (price.contains(",")) {
            price = price.replace(",", "");
        }

        if(price.matches("[a-zA-Z]"))
        {price = price.replaceAll("[a-zA-Z]", "");}
        if (price.contains(".")) {
            if (price.startsWith(".")) {
                if (price.substring(1).length() == 1)
                    price = price.substring(1) + 0;
                else {
                    price = price.substring(1, 3);
                }

            } else {
                String[] strArr = price.split("\\.");
                price = price.substring(1) + 0;
                if (strArr[1].length() == 1) {
                    price = strArr[0] + strArr[1].substring(0) + 0;
                } else {
                    price = strArr[0] + strArr[1].substring(0, 2);
                }
            }
        }
        int priceint = Integer.parseInt(price);
        return makePrice(priceint);
    }
}
