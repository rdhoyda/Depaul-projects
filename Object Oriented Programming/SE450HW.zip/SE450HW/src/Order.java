

public class  Order{
    private final String user;
    private final String product;
    private final Price price;
    private final BookSide side;
    private final String id;
    private final int originalVolume;
    public int remainingVolume;
    public int cancelledVolume;
    public int filledVolume;

    public Order(String user, String product, Price price, BookSide side, int originalVolume) throws OrderValidationException {
        this.user = verifyUser(user);
        this.product = verifyProduct(product);
        this.price = verifyPrice(price);
        this.side = side;
        this.id = generateId();
        this.originalVolume = verifyOriginalVolume(originalVolume);
        this.remainingVolume = originalVolume;
        this.cancelledVolume = 0;
        this.filledVolume = 0;
    }

    public String getUser() {
        return user;
    }

    public String getProduct() {
        return product;
    }

    public Price getPrice() {
        return price;
    }

    public BookSide getSide() {
        return side;
    }

    public String getId() {
        return id;
    }

    public int getOriginalVolume() {
        return originalVolume;
    }

    public int getRemainingVolume() {
        return remainingVolume;
    }

    public int getCancelledVolume() {
        return cancelledVolume;
    }

    public int getFilledVolume() {
        return filledVolume;
    }

    public void setRemainingVolume(int remainingVolume) {
        this.remainingVolume = remainingVolume;
    }

    public void setCancelledVolume(int cancelledVolume) {
        this.cancelledVolume = cancelledVolume;
    }

    public void setFilledVolume(int filledVolume) {
        this.filledVolume = filledVolume;
    }

    private Price verifyPrice(Price price) throws OrderValidationException {
        if(price == null)
        {throw new OrderValidationException("Verify Price object passed, it cannot be null");}
        return price;
    }

    private String verifyProduct(String product) throws OrderValidationException {
        if(product == null || product.contains(".")&&!(product.replace(".","").length()>=1)|| !product.matches("^[A-Za-z0-9]{1,5}$"))
        {throw new OrderValidationException("Verify product symbol passed in");}

        return product;

    }

    private String verifyUser(String user) throws OrderValidationException {

        if(user == null || !user.matches("^[A-Za-z]{3}$"))
        {throw new OrderValidationException("Verify user code passed in");}

        return user;

    }

    private int verifyOriginalVolume(int originalVolume) throws OrderValidationException {
        if(originalVolume >= 10000 || originalVolume<=0)
        { throw new OrderValidationException("Verify original volume passed in"); }
        return originalVolume;
    }



    public void fill(int volume) {
        filledVolume += volume;
        remainingVolume -= volume;
    }

    private String generateId() {
        long nanoTime = System.nanoTime();
        return user + product + price.toString() + nanoTime;
    }

    @Override
    public String toString() {
        return getUser()+" order: " +getSide()+" "+getProduct()+" at "+getPrice().toString()+", Orig Vol: "+getOriginalVolume()+" , Rem Vol: "+getRemainingVolume()+", Fill Vol: "+getFilledVolume()+", CXL Vol: "+getCancelledVolume()+", ID: "+getId();}


    public OrderDTO makeTradableDTO() {
        return new OrderDTO(this);
    }
}
