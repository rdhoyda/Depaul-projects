

public class OrderDTO {
    public  String user;
    public  String product;
    public Price price;
    public BookSide side;
    public  String id;
    public  int originalVolume;
    public int remainingVolume;
    public int cancelledVolume = 0;
    public int filledVolume = 0;

    public OrderDTO(Order order)
    {
        this.user = order.getUser();
        this.product = order.getProduct();
        this.price = order.getPrice();
        this.side = order.getSide();
        this.id = order.getId();
        this.originalVolume = order.getOriginalVolume();
        this.remainingVolume = order.getRemainingVolume();
        this.cancelledVolume = order.getCancelledVolume();
        this.filledVolume = order.getFilledVolume();
    }

    public String toString()
    { return this.user+" order: " +this.product+" at "+this.price.toString()+", Orig Vol: "+this.originalVolume+" , Rem Vol: "+this.remainingVolume+", Fill Vol: "+this.filledVolume+", CXL Vol: "+this.cancelledVolume+", ID: "+this.id;}


}
