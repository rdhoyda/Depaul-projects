
public class InvalidPriceOperation extends Exception{

    public InvalidPriceOperation(String errorMessage){
        super(errorMessage);


    }
}