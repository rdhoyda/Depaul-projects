

import java.util.HashMap;
import java.util.Random;

public class TrafficSim {

    private static HashMap<String, Double> basePrices = new HashMap<>();

    public static void runSim() throws InvalidPriceOperation, OrderValidationException {
        UserManager.getInstance().init(new String[]{"ANN", "BOB", "CAT", "DOG", "EGG"});
        ProductManager.getInstance().addProduct("WMT");
        ProductManager.getInstance().addProduct("TGT");
        ProductManager.getInstance().addProduct("AMZN");
        ProductManager.getInstance().addProduct("TSLA");

        basePrices.put("WMT", 140.98);
        basePrices.put("TGT", 174.76);
        basePrices.put("AMZN", 102.11);
        basePrices.put("TSLA", 196.81);

        for(int i =0; i<40; i++)
        {
            System.out.println(i+1);
            User user = UserManager.getInstance().getRandomUser();
            if(Math.random() < 0.9)
            {
                String value =  ProductManager.getInstance().getRandomProduct();
                BookSide side = BookSide.values()[new Random().nextInt(BookSide.values().length)];
                int calculatedVol = (int) Math.round((int) (25 + (Math.random() * 300)) / 5.0) * 5;
                Price price = getPrice(value, side);
                Order order = new Order(user.getUserID(), value, price, side, calculatedVol);
                OrderDTO dtoObject = ProductManager.getInstance().addOrder(order);
                user.addOrder(dtoObject);
            }
            else{
                if(user.hasOrderWithRemainingQty())
                {
                    OrderDTO orderDTO = user.getOrderWithRemainingQty();
                    if(orderDTO != null) {
                        OrderDTO canceldto = ProductManager.getInstance().cancel(orderDTO);
                        if (canceldto != null) {
                            user.addOrder(canceldto);
                        }
                    }
                }


            }
        }
        System.out.println("----------------------------------------------------------------------------------------------------\n ProductBooks: \n");
        System.out.println(ProductManager.getInstance().toString());

        System.out.println("----------------------------------------------------------------------------------------------------\n Users: \n");
        System.out.println(UserManager.getInstance().toString());

    }

    static Price  getPrice(String symbol, BookSide side)
    {
        double users  = basePrices.get(symbol);
        double priceWidth = 0.02;
        double startPoint = 0.01;
        double tickSize = 0.1;
        double gapFromBase = users * priceWidth; // 5.0
        double priceVariance = gapFromBase * (Math.random());
        double priceToTick ;
        if(side.equals(BookSide.BUY))
        {
            double priceToUse = users * (1 - startPoint);
            priceToUse += priceVariance;
            priceToTick = Math.round(priceToUse * 1/tickSize) / 20.0;
        }
        else
        {
            double priceToUse = users * (1 + startPoint);
            priceToUse -= priceVariance;
            priceToTick = Math.round(priceToUse * 1/tickSize) / 20.0;
        }
        Price price = PriceFactory.makePrice((int)Math.floor(priceToTick*100));
        return price;
    }

}
