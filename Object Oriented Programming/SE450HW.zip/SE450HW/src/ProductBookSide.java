
import java.util.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

// ProductBookSide class representing one side (Buy or Sell) of a product book
class ProductBookSide {
    private final BookSide side;
   final HashMap<Price, ArrayList<Order>> bookEntries;

    public ProductBookSide(BookSide side, HashMap<Price, ArrayList<Order>> bookEntries) throws InvalidPriceOperation {
        if(side == null)
        {throw new InvalidPriceOperation("side should not be null");}
        this.side = side;
        this.bookEntries = bookEntries;
    }

    public OrderDTO add(Order order) {
        Price price = order.getPrice();
        ArrayList list = new ArrayList<Order>();
        list.add(order);
        if(!bookEntries.containsKey(price))
        {bookEntries.put(price, list);}
        else {bookEntries.get(price).add(order);}
        return order.makeTradableDTO();
    }

    public OrderDTO cancel(String orderId) {
        for (ArrayList<Order> orders : bookEntries.values()) {
            for (Order order : orders) {
                if (order.getId().equals(orderId)) {
                    orders.remove(order);
                    order.setCancelledVolume(order.getRemainingVolume());
                    order.setRemainingVolume(0);
                    if (orders.isEmpty())
                        bookEntries.remove(order.getPrice());
                    return order.makeTradableDTO();
                }
            }
        }
        return null;
    }

    public Price topOfBookPrice() {
        if (bookEntries.isEmpty()) {
            return null;
        }

        if (side.equals(BookSide.BUY)) {
            return bookEntries.keySet().stream()
                    .max(Comparator.comparingInt(Price::getPrice))
                    .orElse(null);
        } else {
            return bookEntries.keySet().stream()
                    .min(Comparator.comparingInt(Price::getPrice))
                    .orElse(null);
        }
    }

    public int topOfBookVolume() {
        Price topPrice = topOfBookPrice();
        if (topPrice != null) {
            return bookEntries.get(topPrice).stream()
                    .mapToInt(Order::getRemainingVolume)
                    .sum();
        }
        return 0;
    }

    public void tradeOut(Price price, int volume) throws OrderValidationException {
        int remainingVolume = volume;
        StringBuilder str = new StringBuilder();
        ArrayList<Order> bookEntryOrders = bookEntries.get(price);
        while (remainingVolume > 0) {
            if (bookEntryOrders.isEmpty()) {
                bookEntries.remove(price);
                return;
            } else {
                Order initialOrder = bookEntryOrders.get(0);
                if (initialOrder.getRemainingVolume() <= remainingVolume) {
                    bookEntryOrders.remove(initialOrder);
                    initialOrder.setFilledVolume(initialOrder.getFilledVolume() + initialOrder.getRemainingVolume());
                    str.append("   FILL: (" + side + " " + initialOrder.remainingVolume + ")");
                    initialOrder.setRemainingVolume(0);
                    System.out.println(str.append(initialOrder.toString()));
                    remainingVolume -= initialOrder.getRemainingVolume();
                    str.delete(0, str.length());
                    OrderDTO orderDTO = initialOrder.makeTradableDTO();
                    UserManager.getInstance().addToUser(initialOrder.getUser(), orderDTO);
                } else {
                    initialOrder.setFilledVolume(initialOrder.getFilledVolume() + remainingVolume);
                    initialOrder.setRemainingVolume(initialOrder.getRemainingVolume() - remainingVolume);
                    remainingVolume = 0;
                    System.out.println(str.append("   PARTIAL FILL: (" + side + " " + initialOrder.getFilledVolume() + ") " + initialOrder.toString()));
                    OrderDTO orderDTO = initialOrder.makeTradableDTO();
                    UserManager.getInstance().addToUser(initialOrder.getUser(), orderDTO);
                }
            }
        }
    }

        public String toString() {
            StringBuilder str = new StringBuilder();
            if (side.equals(BookSide.BUY)) {
                TreeMap<Price, ArrayList<Order>> dscList = new TreeMap<>();
                dscList.putAll(bookEntries);
                str.append("Side: " + side);
                for (Price prices : dscList.descendingKeySet()) {
                    str.append("\n  Price: " + prices.toString());
                    for (Order orders : bookEntries.get(prices)) {
                        str.append("\n      " + orders.toString());
                    }
                }
            } else {
                TreeMap<Price, ArrayList<Order>> ascList = new TreeMap<>();
                ascList.putAll(bookEntries);
                str.append("Side: " + side);
                for (Price prices: ascList.keySet()) {
                    str.append("\n   Price: " + prices.toString());
                    for (Order orders : bookEntries.get(prices)) {
                        str.append("\n      " + orders.toString());
                    }
                }
            }
            return str.toString();

        }
    }