

import java.util.HashMap;
import java.util.Random;

public class TrafficSim {

    private static HashMap<String, Double> basePrices = new HashMap<>();

    public static void runSim() throws InvalidPriceOperation, OrderValidationException {
        UserManager.getInstance().init(new String[]{"ANN", "BOB", "CAT", "DOG", "EGG"});

        User user1 = UserManager.getInstance().getUser("ANN");
        User user2 = UserManager.getInstance().getUser("BOB");
        User user3 = UserManager.getInstance().getUser("CAT");
        User user4 = UserManager.getInstance().getUser("DOG");
        User user5 = UserManager.getInstance().getUser("EGG");

        ProductManager.getInstance().addProduct("WMT");
        ProductManager.getInstance().addProduct("TGT");
        ProductManager.getInstance().addProduct("AMZN");
        ProductManager.getInstance().addProduct("TSLA");

        CurrentMarketPublisher.getInstance().subscribeCurrentMarket("WMT", user1);
        CurrentMarketPublisher.getInstance().subscribeCurrentMarket("TGT", user1);

        CurrentMarketPublisher.getInstance().subscribeCurrentMarket("TGT", user2);
        CurrentMarketPublisher.getInstance().subscribeCurrentMarket("TSLA", user2);

        CurrentMarketPublisher.getInstance().subscribeCurrentMarket("AMZN", user3);
        CurrentMarketPublisher.getInstance().subscribeCurrentMarket("TGT", user3);
        CurrentMarketPublisher.getInstance().subscribeCurrentMarket("WMT", user3);

        CurrentMarketPublisher.getInstance().subscribeCurrentMarket("TSLA", user4);

        CurrentMarketPublisher.getInstance().subscribeCurrentMarket("WMT", user5);

        CurrentMarketPublisher.getInstance().unSubscribeCurrentMarket("TGT", user2);


        basePrices.put("WMT", 140.98);
        basePrices.put("TGT", 174.76);
        basePrices.put("AMZN", 102.11);
        basePrices.put("TSLA", 196.81);

        for(int i =0; i<10000; i++)
        {
            System.out.println(i+1);
            User user = UserManager.getInstance().getRandomUser();
            if(Math.random() < 0.9)
            {
                String value =  ProductManager.getInstance().getRandomProduct();
                BookSide side = BookSide.values()[new Random().nextInt(BookSide.values().length)];
                int calculatedVol = (int) Math.round((int) (25 + (Math.random() * 300)) / 5.0) * 5;
                Price price = getPrice(value, side);
                Order order = new Order(user.getUserID(), value, price, side, calculatedVol);
                OrderDTO dto = ProductManager.getInstance().addOrder(order);
                user.addOrder(dto);
            }
            else{
                if(user.hasOrderWithRemainingQty())
                {
                    OrderDTO orderDTO = user.getOrderWithRemainingQty();
                    if(orderDTO != null) {
                        OrderDTO cancel = ProductManager.getInstance().cancel(orderDTO);
                        if (cancel != null) {
                            user.addOrder(cancel);
                        }
                    }
                }


            }
        }

        System.out.println(user1.getUserID()+"\n"+user1.getCurrentMarkets());
        System.out.println(user2.getUserID()+"\n"+user2.getCurrentMarkets());
        System.out.println(user3.getUserID()+"\n"+user3.getCurrentMarkets());
        System.out.println(user4.getUserID()+"\n"+user4.getCurrentMarkets());
        System.out.println(user5.getUserID()+"\n"+user5.getCurrentMarkets());

        CurrentMarketPublisher.getInstance().unSubscribeCurrentMarket("WMT", user1);
        CurrentMarketPublisher.getInstance().unSubscribeCurrentMarket("TGT", user1);

        CurrentMarketPublisher.getInstance().unSubscribeCurrentMarket("TSLA", user2);

        CurrentMarketPublisher.getInstance().unSubscribeCurrentMarket("AMZN", user3);
        CurrentMarketPublisher.getInstance().unSubscribeCurrentMarket("TGT", user3);
        CurrentMarketPublisher.getInstance().unSubscribeCurrentMarket("WMT", user3);

        CurrentMarketPublisher.getInstance().unSubscribeCurrentMarket("TSLA", user4);

        CurrentMarketPublisher.getInstance().unSubscribeCurrentMarket("WMT", user5);


    }

    static Price  getPrice(String symbol, BookSide side)
    {
        double users  = basePrices.get(symbol);
        double priceWidth = 0.02;
        double startPoint = 0.01;
        double tickSize = 0.1;
        double gapFromBase = users * priceWidth; // 5.0
        double priceVariance = gapFromBase * (Math.random());
        double priceToTick ;
        if(side.equals(BookSide.BUY))
        {
            double priceToUse = users * (1 - startPoint);
            priceToUse += priceVariance;
            priceToTick = Math.round(priceToUse * 1/tickSize) / 20.0;
        }
        else
        {
            double priceToUse = users * (1 + startPoint);
            priceToUse -= priceVariance;
            priceToTick = Math.round(priceToUse * 1/tickSize) / 20.0;
        }
        Price price = PriceFactory.makePrice((int)Math.floor(priceToTick*100));
        return price;
    }

}
