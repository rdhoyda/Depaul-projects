

public class CurrentMarketTracker {

    private static CurrentMarketTracker singleTracker = null;

    private CurrentMarketTracker() { }

    public static CurrentMarketTracker getInstance()
    {
        if (singleTracker == null)
            singleTracker = new CurrentMarketTracker();
        return singleTracker;
    }

    public void updateMarket(String symbol, Price buyPrice, int buyVolume, Price sellPrice, int sellVolume)
    {
        int marketWidth =0;
        if(sellPrice != null && buyPrice != null)
            marketWidth = buyPrice.compareTo(sellPrice);
        if(buyPrice == null) {buyPrice = PriceFactory.makePrice(0);}
        if(sellPrice == null){sellPrice = PriceFactory.makePrice(0);}
        CurrentMarketSide currentMarketSideBuy = new CurrentMarketSide(buyPrice, buyVolume);
        CurrentMarketSide currentMarketSideSell = new CurrentMarketSide(sellPrice, sellVolume);
        System.out.println("*********** Current Market ***********\n" +
                symbol+ currentMarketSideBuy.toString() +" - "+ currentMarketSideSell.toString()+ " [$"+marketWidth+"]");

        CurrentMarketPublisher.getInstance().acceptCurrentMarket(symbol,currentMarketSideBuy,currentMarketSideSell);
    }
}
