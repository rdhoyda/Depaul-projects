import java.util.ArrayList;
import java.util.HashMap;

public class ProductBook {
    private String product;
    private ProductBookSide buySide;
    private ProductBookSide sellSide;

    public ProductBook(String product) throws OrderValidationException, InvalidPriceOperation {
        this.product = verifyProduct(product);
        HashMap<Price, ArrayList<Order>> bsMap = new HashMap<>();
        HashMap<Price, ArrayList<Order>> ssMap = new HashMap<>();
        buySide = new ProductBookSide(BookSide.BUY, bsMap);
        sellSide = new ProductBookSide(BookSide.SELL, ssMap);

    }

    private String verifyProduct(String product) throws OrderValidationException {
        if(product == null || product.contains(".")&&!(product.replace(".","").length()>=1)|| !product.matches("^[A-Za-z0-9]{1,5}$"))
        throw new OrderValidationException("Verify product symbol passed in");
        return product;
    }

    public OrderDTO add(Order o) throws InvalidPriceOperation , OrderValidationException{
        ProductBookSide bookSide = o.getSide().equals( BookSide.BUY) ? buySide : sellSide;
        OrderDTO orderDTO = bookSide.add(o);
        System.out.println("ADD: "+o.getSide()+" :"+o.toString());

        tryTrade();
        updateMarket();
        return orderDTO;
    }

    public OrderDTO cancel(BookSide side, String orderId) {
        ProductBookSide bookSide = side.equals(BookSide.BUY) ? buySide : sellSide;
        OrderDTO orderDTO = bookSide.cancel(orderId);
        updateMarket();
        if(orderDTO != null)
        { System.out.println("CANCEL: "+side+" ORDER: "+orderId+" Cxl Qty:"+orderDTO.cancelledVolume);}
        return bookSide.cancel(orderId);
    }
    public void tryTrade() throws InvalidPriceOperation, OrderValidationException {
        ProductBookSide buySide = this.buySide;
        ProductBookSide sellSide = this.sellSide;

        Price buyPrice = buySide.topOfBookPrice();
        Price sellPrice = sellSide.topOfBookPrice();

        while (buyPrice != null && sellPrice != null && buyPrice.greaterOrEqual(sellPrice)) {
            int buyVolume = buySide.topOfBookVolume();
            int sellVolume = sellSide.topOfBookVolume();
            int tradeVolume = Math.min(buyVolume, sellVolume);

            buySide.tradeOut(buyPrice, tradeVolume);
            sellSide.tradeOut(sellPrice, tradeVolume);
            sellPrice = sellSide.topOfBookPrice();
            buyPrice = buySide.topOfBookPrice();
            }
    }

    private void updateMarket()
    {
        CurrentMarketTracker.getInstance().updateMarket(product, buySide.topOfBookPrice(), buySide.topOfBookVolume(), sellSide.topOfBookPrice(), sellSide.topOfBookVolume());
    }

    @Override
    public String toString(){
        return ("Product: "+product+"\n"+buySide.toString()+"\n"+sellSide.toString());
    }
}
