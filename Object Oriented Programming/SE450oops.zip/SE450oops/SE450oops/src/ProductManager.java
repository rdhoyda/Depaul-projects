

import java.util.HashMap;
import java.util.Random;

public class ProductManager {

    private HashMap<String, ProductBook> productManagerMap = new HashMap<>();
    private static ProductManager singleProduct = null;

    private ProductManager()
    {

    }

    public static ProductManager getInstance()
    {
        if (singleProduct == null)
            singleProduct = new ProductManager();

        return singleProduct;
    }

    public void addProduct(String value) throws InvalidPriceOperation, OrderValidationException {
        if(!productManagerMap.containsKey(value))
            this.productManagerMap.put(value, new ProductBook(value));

    }

    public String getRandomProduct()
    {
        if(!productManagerMap.isEmpty()){
            Object[] products = this.productManagerMap.keySet().toArray();
            Object product = products[new Random().nextInt(products.length)];
            return product.toString();}
        else return null;
    }

    public OrderDTO addOrder(Order order) throws InvalidPriceOperation, OrderValidationException {
        OrderDTO orderdto = null;
        if(productManagerMap.get(order.getProduct()) != null)
            orderdto =  productManagerMap.get(order.getProduct()).add(order);
        return orderdto;
    }

    public OrderDTO cancel(OrderDTO orderDTO)
    {
        OrderDTO orderdto = null;
        if(productManagerMap.get(orderDTO.product) != null)
            orderdto =  productManagerMap.get(orderDTO.product).cancel(orderDTO.side, orderDTO.id);
        else if (orderDTO == null)
        {System.out.println("Cancel Failed");}
        return orderdto;
    }

    @Override
    public String toString() {
        StringBuilder str = new StringBuilder();
        for(ProductBook pb : productManagerMap.values())
        {str.append(pb.toString());}
        return str.toString();
    }
}
