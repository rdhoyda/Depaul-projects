import java.text.NumberFormat;
import java.util.Objects;

public class Price implements Comparable<Price>{
    private int price;

    public Price(int price) {
        this.price = price;
    }

    public int getPrice() {
        return price;
    }

    public boolean isNegative(){
        if(this.price < 0)
            return true;
        else return false;
    }

    public Price add(Price price) throws InvalidPriceOperation {
        if(price == null)
        throw new InvalidPriceOperation("price cannot be null");

        int sum = this.price + price.price;
        Price addPrice = PriceFactory.makePrice(sum);
        return addPrice;
    }

    public Price subtract(Price price) throws InvalidPriceOperation {
        if(price == null)
            throw new InvalidPriceOperation("price cannot be null");

        int sub = this.price-price.price;
        Price subPrice = PriceFactory.makePrice(sub);
        return subPrice;
    }

    public Price multiply(int num) {
        int result = this.price*num;
        Price mulPrice = PriceFactory.makePrice(result);
        return mulPrice;
    }

    public boolean greaterOrEqual(Price price) throws InvalidPriceOperation {
        if(price == null)
        throw new InvalidPriceOperation("price.cannot be null");

        if(this.price >= price.price)
            return true;
        else
            return false;
    }

    public boolean lessOrEqual(Price price) throws InvalidPriceOperation {
        if(price == null)
        throw new InvalidPriceOperation("price cannot be null");

        if(this.price <= price.price)
            return true;
        else
            return false;
    }

    public boolean greaterThan(Price price) throws InvalidPriceOperation {
        if(price == null)
        throw new InvalidPriceOperation("price cannot be null");

        if(this.price > price.price)
            return true;
        else
            return false;
    }

    public boolean lessThan(Price price) throws InvalidPriceOperation {
        if(price == null)
         throw new InvalidPriceOperation("price cannot be null");

        if(this.price < price.price)
            return true;
        else
            return false;
    }



    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Price price = (Price) o;
        return this.price == price.price;
    }

    @Override
    public int hashCode() {
        return Objects.hash(price);
    }

    @Override
    public int compareTo(Price price) {

        if(price == null)
        {
            System.out.println("Price object passed to compare with is null");
        }
        return Math.abs(this.price - price.price);

    }

    @Override
    public String toString() {
        NumberFormat nfor = NumberFormat.getInstance();
        return Math.abs(price%100) ==0 || Math.abs(price%100) <10 ? "$" + nfor.format(price/100)+'.'+Math.abs(price%100)+"0" : "$" + nfor.format(price/100)+'.'+Math.abs(price%100);
    }
}
