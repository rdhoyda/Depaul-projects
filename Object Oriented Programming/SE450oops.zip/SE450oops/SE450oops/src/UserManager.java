import java.util.HashMap;
import java.util.Random;

public class UserManager{
    private HashMap<String, User> userManagerMap = new HashMap<>();
        private static UserManager singleuser = null;

        private UserManager() { }

        public static UserManager getInstance()
        {
            if (singleuser == null)
                singleuser = new UserManager();

            return singleuser;
        }

        public void init(String[] users) throws OrderValidationException {
            for(String userid : users)
            { this.userManagerMap.put(userid, new User(userid)); }
        }

        public User getRandomUser()
        {
            if(userManagerMap.isEmpty())
            {
                return null;
            }
            Object[] userids = this.userManagerMap.keySet().toArray();
            Object user = userids[new Random().nextInt(userids.length)];
            return userManagerMap.get(user);
        }

        public void addToUser(String userId, OrderDTO order) throws OrderValidationException {
            if(userManagerMap.containsKey(userId))
            {userManagerMap.get(userId).addOrder(order);}
            else {
                throw new OrderValidationException("userId missing in map");
            }
        }

    public User getUser(String id)
    {
        return userManagerMap.get(id);
    }

        @Override
        public String toString() {
            StringBuilder strbuild = new StringBuilder();
            for(User userId : userManagerMap.values())
            {strbuild.append(userId.toString());}
            return strbuild.toString();
        }
}

