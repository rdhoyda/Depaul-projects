public class OrderValidationException extends Exception{

    public OrderValidationException(String errorMessage){
        super(errorMessage);


    }
}