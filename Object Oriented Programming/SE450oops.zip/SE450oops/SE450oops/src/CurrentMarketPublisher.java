import java.util.ArrayList;
import java.util.HashMap;

public class CurrentMarketPublisher {

    private HashMap<String, ArrayList<CurrentMarketObserver>> filters = new HashMap<>();
    public static CurrentMarketPublisher singlePublisher = null;

    private CurrentMarketPublisher() {
    }

    public static CurrentMarketPublisher getInstance() {
        if (singlePublisher == null)
            singlePublisher = new CurrentMarketPublisher();

        return singlePublisher;
    }

    public void subscribeCurrentMarket(String symbol, CurrentMarketObserver cmo) {
        ArrayList<CurrentMarketObserver> list =  filters.get(symbol);
        if(list == null) {
            list = new ArrayList<CurrentMarketObserver>();
            list.add(cmo);
            filters.put(symbol, list);
        }
        else list.add(cmo);
    }

    public void unSubscribeCurrentMarket(String symbol, CurrentMarketObserver cmo) {

        ArrayList<CurrentMarketObserver> list = filters.get(symbol);
        if (list == null)
            return;
        else
            list.remove(cmo);
        filters.put(symbol, list);
    }

    void acceptCurrentMarket(String symbol, CurrentMarketSide buySide, CurrentMarketSide sellSide) {
        if (filters.containsKey(symbol)) {
            ArrayList<CurrentMarketObserver> list = filters.get(symbol);
            for (CurrentMarketObserver currentMarketObserver : list)
                currentMarketObserver.updateCurrentMarket(symbol, buySide, sellSide);
        }

    }
}

