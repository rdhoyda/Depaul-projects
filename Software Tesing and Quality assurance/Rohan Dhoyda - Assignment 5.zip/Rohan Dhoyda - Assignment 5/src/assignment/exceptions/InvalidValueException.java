package assignment.exceptions;

public class InvalidValueException extends Exception {
    public InvalidValueException(String s) {
        super(s);
    }
}
