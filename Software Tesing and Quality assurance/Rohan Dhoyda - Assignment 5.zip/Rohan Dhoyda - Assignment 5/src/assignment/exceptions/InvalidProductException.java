package assignment.exceptions;

public class InvalidProductException extends Exception {
    public InvalidProductException(String s) {
        super(s);
    }
}
