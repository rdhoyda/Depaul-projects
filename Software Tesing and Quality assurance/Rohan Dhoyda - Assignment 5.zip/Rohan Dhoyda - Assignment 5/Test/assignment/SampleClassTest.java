package assignment;

import assignment.exceptions.InvalidProductException;
import assignment.exceptions.InvalidValueException;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class SampleClassTest {

    @Test
    void calculateTaxRate() throws InvalidProductException {
        SampleClass newsample = new SampleClass();

        double tax = newsample.calculateTaxRate("Bakery");
        assertEquals(0.05, tax);

        double tax1 = newsample.calculateTaxRate("Beverage");
        assertEquals(0.075, tax1);

        double tax2 = newsample.calculateTaxRate("Deli");
        assertEquals(0.065, tax2);

        double tax3 = newsample.calculateTaxRate("Meat");
        assertEquals(0.065, tax3);

        double tax4 = newsample.calculateTaxRate("Produce");
        assertEquals(0.04, tax4);

        double tax5 = newsample.calculateTaxRate("Seafood");
        assertEquals(0.06, tax5);



        assertThrows(InvalidProductException.class, () -> newsample.calculateTaxRate("Rohan"));





    }


    @Test
    void getDensityQualifier() throws InvalidValueException {
        SampleClass newsample = new SampleClass();

        String qualifier = newsample.getDensityQualifier(120);
        assertEquals("ldpi", qualifier);

        String qualifier1 = newsample.getDensityQualifier(160);
        assertEquals("mdpi", qualifier1);

        String qualifier2 = newsample.getDensityQualifier(240);
        assertEquals("hdpi", qualifier2);

        String qualifier3 = newsample.getDensityQualifier(320);
        assertEquals("xhdpi", qualifier3);

        String qualifier4 = newsample.getDensityQualifier(480);
        assertEquals("xxhdpi", qualifier4);

        String qualifier5 = newsample.getDensityQualifier(640);
        assertEquals("xxxhdpi", qualifier5);

        String qualifier6 = newsample.getDensityQualifier(213);
        assertEquals("tvdpi", qualifier6);

        String qualifier7 = newsample.getDensityQualifier(1000);
        assertEquals("nodpi", qualifier7);

        assertThrows(InvalidValueException.class, () -> newsample.getDensityQualifier(-1));
        ;
    }



}

